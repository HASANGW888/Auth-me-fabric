package dev.authme.fabric;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/** JDBC datasource: SQLite, MySQL, MariaDB, PostgreSQL. Column names follow AuthMe's defaults. */
public class Database implements AutoCloseable {
    public record Account(String name, String realName, String hash, String ip,
                          long lastLogin, long regDate, String regIp, String totp) {}

    private static final String COLS = "username,realname,password,ip,lastlogin,regdate,regip,totp";

    private final String backend, url, user, pass, table;
    private Connection conn;

    public Database(Settings s) throws Exception {
        backend = s.str("DataSource.backend", "SQLITE").toUpperCase();
        table = s.str("DataSource.mySQLTablename", "authme").replaceAll("[^A-Za-z0-9_]", "");
        String host = s.str("DataSource.mySQLHost", "127.0.0.1");
        String port = s.str("DataSource.mySQLPort", "3306");
        String db = s.str("DataSource.mySQLDatabase", "authme");
        switch (backend) {
            case "SQLITE" -> { url = "jdbc:sqlite:" + Config.dir().resolve("authme.db").toAbsolutePath(); user = null; pass = null; }
            case "POSTGRESQL" -> { url = "jdbc:postgresql://" + host + ":" + (port.equals("3306") ? "5432" : port) + "/" + db;
                user = s.str("DataSource.mySQLUsername", "authme"); pass = s.str("DataSource.mySQLPassword", ""); }
            case "MYSQL", "MARIADB" -> { url = "jdbc:mariadb://" + host + ":" + port + "/" + db;
                user = s.str("DataSource.mySQLUsername", "authme"); pass = s.str("DataSource.mySQLPassword", ""); }
            default -> throw new IllegalArgumentException("Unknown DataSource.backend: " + backend);
        }
        connect();
        String id = switch (backend) {
            case "SQLITE" -> "id INTEGER PRIMARY KEY AUTOINCREMENT";
            case "POSTGRESQL" -> "id SERIAL PRIMARY KEY";
            default -> "id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY";
        };
        try (Statement st = conn.createStatement()) {
            st.executeUpdate("CREATE TABLE IF NOT EXISTS " + table + " (" + id + ","
                    + "username VARCHAR(255) NOT NULL UNIQUE,"
                    + "realname VARCHAR(255) NOT NULL DEFAULT 'Player',"
                    + "password VARCHAR(255) NOT NULL,"
                    + "ip VARCHAR(40),"
                    + "lastlogin BIGINT DEFAULT 0,"
                    + "regdate BIGINT DEFAULT 0,"
                    + "regip VARCHAR(40),"
                    + "totp VARCHAR(32))");
        }
        try (Statement st = conn.createStatement()) {
            st.executeUpdate("ALTER TABLE " + table + " ADD COLUMN totp VARCHAR(32)");
        } catch (SQLException ignored) { /* column already exists */ }
    }

    private void connect() throws SQLException {
        Properties pr = new Properties();
        if (user != null) { pr.setProperty("user", user); pr.setProperty("password", pass); }
        // Instantiate drivers directly: DriverManager can't always see jar-in-jar drivers.
        Driver d = switch (backend) {
            case "SQLITE" -> new org.sqlite.JDBC();
            case "POSTGRESQL" -> new org.postgresql.Driver();
            default -> new org.mariadb.jdbc.Driver();
        };
        conn = d.connect(url, pr);
    }

    private Connection conn() throws SQLException {
        if (conn == null || conn.isClosed() || (!backend.equals("SQLITE") && !conn.isValid(2))) connect();
        return conn;
    }

    private static Account read(ResultSet rs) throws SQLException {
        return new Account(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
                rs.getLong(5), rs.getLong(6), rs.getString(7), rs.getString(8));
    }

    public synchronized Account get(String name) {
        try (PreparedStatement ps = conn().prepareStatement("SELECT " + COLS + " FROM " + table + " WHERE username=?")) {
            ps.setString(1, name.toLowerCase());
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? read(rs) : null; }
        } catch (SQLException e) { throw new RuntimeException(e); }
    }

    public synchronized void insert(String name, String hash, String ip) {
        long now = System.currentTimeMillis();
        exec("INSERT INTO " + table + "(username,realname,password,ip,lastlogin,regdate,regip) VALUES(?,?,?,?,?,?,?)",
                name.toLowerCase(), name, hash, ip, now, now, ip);
    }

    public synchronized void updateLogin(String name, String ip) {
        exec("UPDATE " + table + " SET ip=?, lastlogin=? WHERE username=?", ip, System.currentTimeMillis(), name.toLowerCase());
    }

    public synchronized void expireSession(String name) {
        exec("UPDATE " + table + " SET lastlogin=0 WHERE username=?", name.toLowerCase());
    }

    public synchronized void updatePassword(String name, String hash) {
        exec("UPDATE " + table + " SET password=? WHERE username=?", hash, name.toLowerCase());
    }

    public synchronized void setTotp(String name, String secret) {
        exec("UPDATE " + table + " SET totp=? WHERE username=?", secret, name.toLowerCase());
    }

    public synchronized void delete(String name) {
        exec("DELETE FROM " + table + " WHERE username=?", name.toLowerCase());
    }

    public synchronized int countByRegIp(String ip) {
        try (PreparedStatement ps = conn().prepareStatement("SELECT COUNT(*) FROM " + table + " WHERE regip=?")) {
            ps.setString(1, ip);
            try (ResultSet rs = ps.executeQuery()) { rs.next(); return rs.getInt(1); }
        } catch (SQLException e) { throw new RuntimeException(e); }
    }

    public synchronized List<String> namesByIp(String ip) {
        List<String> out = new ArrayList<>();
        try (PreparedStatement ps = conn().prepareStatement("SELECT realname FROM " + table + " WHERE ip=?")) {
            ps.setString(1, ip);
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) out.add(rs.getString(1)); }
        } catch (SQLException e) { throw new RuntimeException(e); }
        return out;
    }

    public synchronized List<Account> recent(int n) {
        List<Account> out = new ArrayList<>();
        try (PreparedStatement ps = conn().prepareStatement("SELECT " + COLS + " FROM " + table + " ORDER BY lastlogin DESC LIMIT ?")) {
            ps.setInt(1, n);
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) out.add(read(rs)); }
        } catch (SQLException e) { throw new RuntimeException(e); }
        return out;
    }

    /** Deletes accounts whose lastlogin is older than cutoff (epoch ms). Returns number removed. */
    public synchronized int purgeOlderThan(long cutoff) {
        try (PreparedStatement ps = conn().prepareStatement("DELETE FROM " + table + " WHERE lastlogin < ?")) {
            ps.setLong(1, cutoff);
            return ps.executeUpdate();
        } catch (SQLException e) { throw new RuntimeException(e); }
    }

    private void exec(String sql, Object... args) {
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            for (int i = 0; i < args.length; i++) ps.setObject(i + 1, args[i]);
            ps.executeUpdate();
        } catch (SQLException e) { throw new RuntimeException(e); }
    }

    @Override
    public synchronized void close() {
        try { if (conn != null) conn.close(); } catch (Exception ignored) {}
    }
}
