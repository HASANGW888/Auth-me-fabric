package dev.authme.fabric;

import net.minecraft.network.chat.Component;
import org.yaml.snakeyaml.Yaml;

import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public class Messages {
    private final Settings settings;
    private Map<String, Object> root = new HashMap<>();

    public Messages(Settings settings) { this.settings = settings; reload(); }

    @SuppressWarnings("unchecked")
    public void reload() {
        try {
            String lang = settings.str("settings.messagesLanguage", "en");
            Path f = Config.dir().resolve("messages").resolve("messages_" + lang + ".yml");
            if (!Files.exists(f)) {
                Path en = Config.dir().resolve("messages").resolve("messages_en.yml");
                if (!Files.exists(en)) Config.copyResource("/messages_en.yml", en);
                f = en;
            }
            try (Reader r = Files.newBufferedReader(f)) {
                Object o = new Yaml().load(r);
                root = o instanceof Map ? (Map<String, Object>) o : new HashMap<>();
            }
        } catch (Exception e) {
            AuthMeMod.LOGGER.error("Could not load messages", e);
        }
    }

    @SuppressWarnings("unchecked")
    public String get(String key, String... repl) {
        Object cur = root;
        for (String part : key.split("\\.")) {
            if (!(cur instanceof Map)) { cur = null; break; }
            cur = ((Map<String, Object>) cur).get(part);
        }
        String text = cur == null ? key : String.valueOf(cur);
        for (int i = 0; i + 1 < repl.length; i += 2) text = text.replace(repl[i], repl[i + 1]);
        return text.replace('&', '\u00a7');
    }

    public Component comp(String key, String... repl) { return Component.literal(get(key, repl)); }
}
