package dev.authme.fabric;

import org.yaml.snakeyaml.Yaml;

import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Settings {
    private Map<String, Object> root = new HashMap<>();

    public Settings() { reload(); }

    @SuppressWarnings("unchecked")
    public void reload() {
        try {
            Path f = Config.dir().resolve("config.yml");
            if (!Files.exists(f)) Config.copyResource("/default-config.yml", f);
            try (Reader r = Files.newBufferedReader(f)) {
                Object o = new Yaml().load(r);
                root = o instanceof Map ? (Map<String, Object>) o : new HashMap<>();
            }
        } catch (Exception e) {
            AuthMeMod.LOGGER.error("Could not load config.yml, using defaults", e);
        }
    }

    @SuppressWarnings("unchecked")
    private Object get(String path) {
        Object cur = root;
        for (String part : path.split("\\.")) {
            if (!(cur instanceof Map)) return null;
            cur = ((Map<String, Object>) cur).get(part);
        }
        return cur;
    }

    public String str(String p, String def) { Object o = get(p); return o == null ? def : String.valueOf(o); }

    public int integer(String p, int def) {
        Object o = get(p);
        if (o == null) return def;
        try { return Integer.parseInt(String.valueOf(o).trim()); } catch (Exception e) { return def; }
    }

    public boolean bool(String p, boolean def) {
        Object o = get(p);
        return o == null ? def : Boolean.parseBoolean(String.valueOf(o));
    }

    public List<String> list(String p, List<String> def) {
        Object o = get(p);
        if (!(o instanceof List)) return def;
        List<String> out = new ArrayList<>();
        for (Object x : (List<?>) o) out.add(String.valueOf(x));
        return out;
    }
}
