package dev.authme.fabric;

import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

public final class Config {
    private Config() {}

    public static Path dir() {
        return FabricLoader.getInstance().getConfigDir().resolve("authme");
    }

    public static void copyResource(String res, Path target) throws Exception {
        Files.createDirectories(target.getParent());
        try (InputStream in = Config.class.getResourceAsStream(res)) {
            if (in == null) throw new IllegalStateException("Missing resource " + res);
            Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
        }
    }
}
