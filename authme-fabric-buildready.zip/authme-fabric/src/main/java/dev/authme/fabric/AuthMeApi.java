package dev.authme.fabric;

import net.minecraft.server.level.ServerPlayer;

/** Minimal public API for other mods (counterpart of AuthMe's AuthMeApi). */
public final class AuthMeApi {
    private AuthMeApi() {}

    public static boolean isAuthenticated(ServerPlayer p) {
        AuthManager a = AuthMeMod.AUTH;
        return a == null || !a.isUnauthenticated(p);
    }

    public static boolean isRegistered(String name) {
        return AuthMeMod.DB != null && AuthMeMod.DB.get(name) != null;
    }

    public static void forceLogin(ServerPlayer p) {
        if (AuthMeMod.AUTH != null) AuthMeMod.AUTH.forceLogin(p, p.level().getServer());
    }

    public static void forceLogout(ServerPlayer p) {
        if (AuthMeMod.AUTH != null) AuthMeMod.AUTH.deauthenticate(p, p.level().getServer());
    }
}
