package dev.authme.fabric;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.server.level.ServerPlayer;

public class AuthCommands {
    private final AuthManager auth;
    private final Messages m;

    public AuthCommands(AuthManager auth, Messages m) { this.auth = auth; this.m = m; }

    private static RequiredArgumentBuilder<CommandSourceStack, String> arg(String n) {
        return Commands.argument(n, StringArgumentType.word());
    }

    private static String s(CommandContext<CommandSourceStack> c, String n) { return StringArgumentType.getString(c, n); }

    private int usage(CommandContext<CommandSourceStack> c, String key) {
        c.getSource().sendSystemMessage(m.comp(key));
        return 0;
    }

    @FunctionalInterface private interface Act { void run(ServerPlayer p, CommandContext<CommandSourceStack> c) throws CommandSyntaxException; }

    private com.mojang.brigadier.Command<CommandSourceStack> act(Act a) {
        return c -> { a.run(c.getSource().getPlayerOrException(), c); return 1; };
    }

    public void register(CommandDispatcher<CommandSourceStack> d) {
        for (String n : new String[]{"login", "l"})
            d.register(Commands.literal(n).executes(c -> usage(c, "login.command_usage"))
                    .then(arg("password").executes(act((p, c) -> auth.login(p, s(c, "password"), c.getSource().getServer())))));

        for (String n : new String[]{"register", "reg"})
            d.register(Commands.literal(n).executes(c -> usage(c, "registration.command_usage"))
                    .then(arg("password").executes(c -> usage(c, "registration.command_usage"))
                            .then(arg("confirm").executes(act((p, c) ->
                                    auth.register(p, s(c, "password"), s(c, "confirm"), c.getSource().getServer()))))));

        d.register(Commands.literal("logout").executes(act((p, c) -> auth.logout(p, c.getSource().getServer()))));

        d.register(Commands.literal("unregister").executes(c -> usage(c, "unregister.command_usage"))
                .then(arg("password").executes(act((p, c) -> auth.unregister(p, s(c, "password"), c.getSource().getServer())))));

        for (String n : new String[]{"changepassword", "cp"})
            d.register(Commands.literal(n).executes(c -> usage(c, "misc.usage_changepassword"))
                    .then(arg("old").executes(c -> usage(c, "misc.usage_changepassword"))
                            .then(arg("new").executes(act((p, c) -> auth.changePassword(p, s(c, "old"), s(c, "new")))))));

        d.register(Commands.literal("captcha").executes(c -> usage(c, "captcha.command_usage"))
                .then(arg("code").executes(act((p, c) -> auth.captcha(p, s(c, "code"))))));

        for (String n : new String[]{"2fa", "totp"})
            d.register(Commands.literal(n).executes(c -> usage(c, "two_factor.usage"))
                    .then(Commands.literal("add").executes(act((p, c) -> auth.totpAdd(p))))
                    .then(Commands.literal("confirm").then(arg("code").executes(act((p, c) -> auth.totpConfirm(p, s(c, "code"))))))
                    .then(Commands.literal("remove").then(arg("code").executes(act((p, c) -> auth.totpRemove(p, s(c, "code"))))))
                    .then(Commands.literal("code").then(arg("code").executes(act((p, c) ->
                            auth.totpLogin(p, s(c, "code"), c.getSource().getServer()))))));
    }
}
