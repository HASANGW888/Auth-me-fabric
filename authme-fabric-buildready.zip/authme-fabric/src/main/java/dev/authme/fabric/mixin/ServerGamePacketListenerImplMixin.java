package dev.authme.fabric.mixin;

import dev.authme.fabric.AuthMeMod;
import net.minecraft.network.protocol.game.ServerboundContainerClickPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Protects the inventory (clicks, item drops, hand swaps) before login. */
@Mixin(ServerGamePacketListenerImpl.class)
public abstract class ServerGamePacketListenerImplMixin {
    @Shadow @Final private ServerPlayer player;

    private boolean authme$blocked() {
        return AuthMeMod.AUTH != null && AuthMeMod.AUTH.protectInventory() && AuthMeMod.AUTH.isUnauthenticated(player);
    }

    @Inject(method = "handleContainerClick", at = @At("HEAD"), cancellable = true)
    private void authme$blockClick(ServerboundContainerClickPacket packet, CallbackInfo ci) {
        if (authme$blocked()) ci.cancel();
    }

    @Inject(method = "handlePlayerAction", at = @At("HEAD"), cancellable = true)
    private void authme$blockAction(ServerboundPlayerActionPacket packet, CallbackInfo ci) {
        if (authme$blocked()) ci.cancel();
    }
}
