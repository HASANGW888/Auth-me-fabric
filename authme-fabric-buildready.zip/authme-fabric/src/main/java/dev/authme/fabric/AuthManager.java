package dev.authme.fabric;

import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.security.SecureRandom;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Core logic: limbo state, login/register flows, captcha, TOTP, restrictions. */
public class AuthManager {
    public static class State {
        String dim; double x, y, z; float yaw, pitch;
        long joinTick;
        boolean needTotp;
        int fails;
        String captcha;
        SpawnManager.Loc limbo; // location to restore after login
    }

    private static final List<String> DEFAULT_CMDS =
            List.of("/login", "/register", "/l", "/reg", "/passpartu", "/email", "/captcha", "/2fa", "/totp");
    private static final String ALNUM = "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789";

    private final Map<UUID, State> pending = new ConcurrentHashMap<>();
    /** Players that completed login/registration/session-resume in this connection. Only these refresh the session on quit. */
    private final Set<UUID> authed = ConcurrentHashMap.newKeySet();
    private final Map<UUID, String> totpSetup = new HashMap<>();
    private final SecureRandom rng = new SecureRandom();

    private final Settings s;
    private final Messages m;
    private final Database db;
    private final SpawnManager spawns;

    public AuthManager(Settings s, Messages m, Database db, SpawnManager spawns) {
        this.s = s; this.m = m; this.db = db; this.spawns = spawns;
    }

    // ---------- helpers ----------
    public boolean isUnauthenticated(net.minecraft.world.entity.player.Player p) { return pending.containsKey(p.getUUID()); }

    public static String name(ServerPlayer p) { return p.getName().getString(); }

    public static String ip(ServerPlayer p) {
        try {
            java.net.SocketAddress a = p.connection.getRemoteAddress();
            if (a instanceof java.net.InetSocketAddress isa && isa.getAddress() != null)
                return isa.getAddress().getHostAddress();
            if (a != null) {
                String x = a.toString();
                if (x.startsWith("/")) x = x.substring(1);
                int i = x.lastIndexOf(':');
                return i > 0 ? x.substring(0, i) : x;
            }
        } catch (Exception ignored) {}
        return "";
    }

    private void msg(ServerPlayer p, String key, String... r) { p.sendSystemMessage(m.comp(key, r)); }

    private void kick(ServerPlayer p, String text) { p.connection.disconnect(Component.literal(text)); }

    public boolean isCommandAllowed(String cmd) {
        String first = cmd.trim().split("\\s+")[0].toLowerCase();
        if (first.startsWith("/")) first = first.substring(1);
        for (String a : s.list("settings.restrictions.allowCommands", DEFAULT_CMDS)) {
            String x = a.toLowerCase();
            if (x.startsWith("/")) x = x.substring(1);
            if (x.equals(first)) return true;
        }
        return false;
    }

    public boolean protectInventory() { return s.bool("settings.restrictions.ProtectInventoryBeforeLogIn", true); }
    public boolean allowChat() { return s.bool("settings.restrictions.allowChat", false); }

    public void denyChat(ServerPlayer p) { msg(p, "error.denied_chat"); }

    // ---------- join / quit ----------
    public void onJoin(ServerPlayer p, MinecraftServer server) {
        String name = name(p);
        String chars = s.str("settings.restrictions.allowedNicknameCharacters", "[a-zA-Z0-9_]*");
        if (!name.matches(chars)) { kick(p, m.get("on_join_validation.characters_in_name", "%valid_chars", chars)); return; }

        int minLen = s.integer("settings.restrictions.minNicknameLength", 3);
        int maxLen = s.integer("settings.restrictions.maxNicknameLength", 16);
        if (name.length() < minLen || name.length() > maxLen) {
            kick(p, m.get("on_join_validation.name_length")); return;
        }

        int maxJoin = s.integer("settings.restrictions.maxJoinPerIp", 0);
        if (maxJoin > 0 && !Permissions.check(p, "authme.allowmultipleaccounts", false)) {
            String myIp = ip(p);
            long same = server.getPlayerList().getPlayers().stream().filter(o -> o != p && ip(o).equals(myIp)).count();
            if (same >= maxJoin) { kick(p, m.get("on_join_validation.same_ip_online")); return; }
        }

        Database.Account acc = db.get(name);
        if (acc != null && !acc.realName().equals(name)) {
            kick(p, m.get("on_join_validation.invalid_name_case", "%valid", acc.realName(), "%invalid", name));
            return;
        }
        if (acc == null && s.bool("settings.restrictions.kickNonRegistered", false)) {
            kick(p, m.get("on_join_validation.not_registered")); return;
        }

        if (acc != null && s.bool("settings.sessions.enabled", false) && ip(p).equals(acc.ip())
                && System.currentTimeMillis() - acc.lastLogin() < s.integer("settings.sessions.timeout", 10) * 60_000L) {
            db.updateLogin(name, ip(p));
            authed.add(p.getUUID());
            msg(p, "misc.session_resumed");
            return;
        }

        State st = new State();
        st.joinTick = server.getTickCount();
        SpawnManager.Loc target = null;
        if (acc == null && spawns.firstSpawn() != null) target = spawns.firstSpawn();
        else if (s.bool("settings.restrictions.teleportUnAuthedToSpawn", false)) target = spawns.spawn();
        if (target != null) {
            st.limbo = SpawnManager.of(p);
            if (spawns.teleport(p, target, server)) { st.dim = target.dim; st.x = target.x; st.y = target.y; st.z = target.z; st.yaw = target.yaw; st.pitch = target.pitch; }
            else { st.limbo = null; target = null; }
        }
        if (target == null) {
            st.dim = p.level().dimension().toString();
            st.x = p.getX(); st.y = p.getY(); st.z = p.getZ(); st.yaw = p.getYRot(); st.pitch = p.getXRot();
        }
        pending.put(p.getUUID(), st);
        remind(p);
    }

    public void onQuit(ServerPlayer p, MinecraftServer server) {
        State st = pending.remove(p.getUUID());
        totpSetup.remove(p.getUUID());
        boolean wasAuthed = authed.remove(p.getUUID());
        if (st == null) {
            // Only players that really authenticated may (re)start a session; kicked/unauthenticated ones must not.
            if (wasAuthed) {
                try { if (db.get(name(p)) != null) db.updateLogin(name(p), ip(p)); } catch (Exception ignored) {}
            }
        } else if (st.limbo != null) {
            try { spawns.teleport(p, st.limbo, server); } catch (Exception ignored) {}
        }
    }

    public void remind(ServerPlayer p) {
        State st = pending.get(p.getUUID());
        if (st != null && st.captcha != null) { msg(p, "captcha.usage_captcha", "%captcha_code", st.captcha); return; }
        if (st != null && st.needTotp) { msg(p, "two_factor.code_required"); return; }
        if (db.get(name(p)) != null) msg(p, "login.login_request");
        else if (s.bool("settings.registration.enabled", true)) msg(p, "registration.register_request");
        else msg(p, "registration.disabled");
    }

    private void authenticate(ServerPlayer p, MinecraftServer server) {
        State st = pending.remove(p.getUUID());
        authed.add(p.getUUID());
        db.updateLogin(name(p), ip(p));
        if (st != null && st.limbo != null) spawns.teleport(p, st.limbo, server);
    }

    public void forceLogin(ServerPlayer p, MinecraftServer server) {
        if (pending.containsKey(p.getUUID())) { authenticate(p, server); msg(p, "login.success"); }
    }

    public void deauthenticate(ServerPlayer p, MinecraftServer server) {
        authed.remove(p.getUUID());
        State st = new State();
        st.joinTick = server.getTickCount();
        st.dim = p.level().dimension().toString();
        st.x = p.getX(); st.y = p.getY(); st.z = p.getZ(); st.yaw = p.getYRot(); st.pitch = p.getXRot();
        pending.put(p.getUUID(), st);
        remind(p);
    }

    // ---------- tick ----------
    public void tick(MinecraftServer server) {
        if (pending.isEmpty()) return;
        long now = server.getTickCount();
        int timeout = s.integer("settings.restrictions.timeout", 30);
        int interval = Math.max(1, s.integer("settings.registration.messageInterval", 5));
        boolean allowMove = s.bool("settings.restrictions.allowMovement", false);
        for (ServerPlayer p : new ArrayList<>(server.getPlayerList().getPlayers())) {
            State st = pending.get(p.getUUID());
            if (st == null) continue;
            long age = now - st.joinTick;
            if (timeout > 0 && age > timeout * 20L) { kick(p, m.get("login.timeout_error")); continue; }
            if (age > 0 && age % (interval * 20L) == 0) remind(p);
            if (!allowMove && st.dim != null && st.dim.equals(p.level().dimension().toString())) {
                double dx = p.getX() - st.x, dz = p.getZ() - st.z;
                if (dx * dx + dz * dz > 0.01) p.connection.teleport(st.x, p.getY(), st.z, st.yaw, st.pitch);
            }
        }
    }

    // ---------- password rules ----------
    /** Returns a message key describing why the password is invalid, or null if OK. */
    public String validatePassword(String name, String pw) {
        int min = s.integer("settings.security.minPasswordLength", 8);
        int max = s.integer("settings.security.passwordMaxLength", 20);
        if (pw.length() < min || pw.length() > max) return "password.wrong_length";
        if (!pw.matches(s.str("settings.restrictions.allowedPasswordCharacters", "[!-~]*"))) return "password.forbidden_characters";
        if (pw.equalsIgnoreCase(name)) return "password.name_in_password";
        for (String u : s.list("settings.security.unsafePasswords", List.of())) if (u.equalsIgnoreCase(pw)) return "password.unsafe_password";
        return null;
    }

    private void sendPwError(ServerPlayer p, String key) {
        msg(p, key, "%valid_chars", s.str("settings.restrictions.allowedPasswordCharacters", "[!-~]*"));
    }

    // ---------- user actions ----------
    public void login(ServerPlayer p, String pw, MinecraftServer server) {
        State st = pending.get(p.getUUID());
        if (st == null) { msg(p, "error.logged_in"); return; }
        Database.Account acc = db.get(name(p));
        if (acc == null) { msg(p, "error.unregistered_user"); return; }
        if (st.captcha != null) { msg(p, "captcha.usage_captcha", "%captcha_code", st.captcha); return; }
        if (st.needTotp) { msg(p, "two_factor.code_required"); return; }

        int maxLoginIp = s.integer("settings.restrictions.maxLoginPerIp", 0);
        if (maxLoginIp > 0 && !Permissions.check(p, "authme.allowmultipleaccounts", false)) {
            String myIp = ip(p);
            long same = server.getPlayerList().getPlayers().stream()
                    .filter(o -> o != p && !pending.containsKey(o.getUUID()) && ip(o).equals(myIp)).count();
            if (same >= maxLoginIp) { msg(p, "login.max_login_ip"); return; }
        }

        if (!PasswordHasher.verify(pw, acc.hash())) {
            st.fails++;
            if (s.bool("Security.captcha.useCaptcha", false) && st.fails >= s.integer("Security.captcha.maxLoginTry", 5)) {
                st.captcha = newCaptcha();
                msg(p, "captcha.usage_captcha", "%captcha_code", st.captcha);
            } else {
                msg(p, "login.wrong_password");
            }
            if (s.bool("settings.restrictions.kickOnWrongPassword", false)) kick(p, m.get("login.wrong_password"));
            return;
        }
        if (acc.totp() != null && !acc.totp().isEmpty()) {
            st.needTotp = true;
            msg(p, "two_factor.code_required");
            return;
        }
        authenticate(p, server);
        msg(p, "login.success");
    }

    public void totpLogin(ServerPlayer p, String code, MinecraftServer server) {
        State st = pending.get(p.getUUID());
        if (st == null || !st.needTotp) { msg(p, "two_factor.not_waiting"); return; }
        Database.Account acc = db.get(name(p));
        if (acc == null || acc.totp() == null || !Totp.verify(acc.totp(), code)) { msg(p, "two_factor.invalid_code"); return; }
        authenticate(p, server);
        msg(p, "login.success");
    }

    public void captcha(ServerPlayer p, String code) {
        State st = pending.get(p.getUUID());
        if (st == null || st.captcha == null) { msg(p, "captcha.not_needed"); return; }
        if (st.captcha.equalsIgnoreCase(code)) {
            st.captcha = null; st.fails = 0;
            msg(p, "captcha.valid_captcha");
        } else {
            st.captcha = newCaptcha();
            msg(p, "captcha.wrong_captcha", "%captcha_code", st.captcha);
        }
    }

    private String newCaptcha() {
        int len = Math.max(3, s.integer("Security.captcha.captchaLength", 5));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < len; i++) sb.append(ALNUM.charAt(rng.nextInt(ALNUM.length())));
        return sb.toString();
    }

    public void register(ServerPlayer p, String pw, String confirm, MinecraftServer server) {
        if (!s.bool("settings.registration.enabled", true)) { msg(p, "registration.disabled"); return; }
        if (db.get(name(p)) != null) { msg(p, "registration.name_taken"); return; }
        if (!pw.equals(confirm)) { msg(p, "password.match_error"); return; }
        String err = validatePassword(name(p), pw);
        if (err != null) { sendPwError(p, err); return; }
        int maxReg = s.integer("settings.restrictions.maxRegPerIp", 3);
        if (maxReg > 0 && !Permissions.check(p, "authme.allowmultipleaccounts", false)) {
            int count = db.countByRegIp(ip(p));
            if (count >= maxReg) { msg(p, "error.max_registration", "%reg_count", String.valueOf(count), "%max_acc", String.valueOf(maxReg)); return; }
        }
        db.insert(name(p), PasswordHasher.hash(pw), ip(p));
        msg(p, "registration.success");
        if (pending.containsKey(p.getUUID())) authenticate(p, server);
    }

    public void logout(ServerPlayer p, MinecraftServer server) {
        if (pending.containsKey(p.getUUID())) { msg(p, "error.not_logged_in"); return; }
        db.expireSession(name(p));
        msg(p, "misc.logout");
        deauthenticate(p, server);
    }

    public void unregister(ServerPlayer p, String pw, MinecraftServer server) {
        if (pending.containsKey(p.getUUID())) { msg(p, "error.not_logged_in"); return; }
        Database.Account acc = db.get(name(p));
        if (acc == null || !PasswordHasher.verify(pw, acc.hash())) { msg(p, "login.wrong_password"); return; }
        db.delete(name(p));
        msg(p, "unregister.success");
        deauthenticate(p, server);
    }

    public void changePassword(ServerPlayer p, String oldPw, String newPw) {
        if (pending.containsKey(p.getUUID())) { msg(p, "error.not_logged_in"); return; }
        Database.Account acc = db.get(name(p));
        if (acc == null || !PasswordHasher.verify(oldPw, acc.hash())) { msg(p, "login.wrong_password"); return; }
        String err = validatePassword(name(p), newPw);
        if (err != null) { sendPwError(p, err); return; }
        db.updatePassword(name(p), PasswordHasher.hash(newPw));
        msg(p, "misc.password_changed");
    }

    // ---------- TOTP management ----------
    public void totpAdd(ServerPlayer p) {
        if (pending.containsKey(p.getUUID())) { msg(p, "error.not_logged_in"); return; }
        Database.Account acc = db.get(name(p));
        if (acc == null) { msg(p, "error.unregistered_user"); return; }
        if (acc.totp() != null && !acc.totp().isEmpty()) { msg(p, "two_factor.already_enabled"); return; }
        String secret = Totp.newSecret();
        totpSetup.put(p.getUUID(), secret);
        msg(p, "two_factor.add_info", "%code", secret,
                "%url", Totp.url(s.str("Security.totp.issuer", "AuthMe"), name(p), secret));
    }

    public void totpConfirm(ServerPlayer p, String code) {
        if (pending.containsKey(p.getUUID())) { msg(p, "error.not_logged_in"); return; }
        String secret = totpSetup.get(p.getUUID());
        if (secret == null) { msg(p, "two_factor.no_setup"); return; }
        if (!Totp.verify(secret, code)) { msg(p, "two_factor.invalid_code"); return; }
        db.setTotp(name(p), secret);
        totpSetup.remove(p.getUUID());
        msg(p, "two_factor.enabled");
    }

    public void totpRemove(ServerPlayer p, String code) {
        if (pending.containsKey(p.getUUID())) { msg(p, "error.not_logged_in"); return; }
        Database.Account acc = db.get(name(p));
        if (acc == null || acc.totp() == null || acc.totp().isEmpty()) { msg(p, "two_factor.not_enabled"); return; }
        if (!Totp.verify(acc.totp(), code)) { msg(p, "two_factor.invalid_code"); return; }
        db.setTotp(name(p), null);
        msg(p, "two_factor.removed");
    }
}
