package dev.authme.fabric;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.*;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AuthMeMod implements ModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("AuthMe");

    public static volatile AuthManager AUTH;
    public static volatile Messages MESSAGES;
    public static volatile Database DB;

    private Database db;

    @Override
    public void onInitialize() {
        Settings settings = new Settings();
        Messages messages = new Messages(settings);
        try {
            db = new Database(settings);
        } catch (Exception e) {
            throw new RuntimeException("AuthMe: could not open database", e);
        }
        SpawnManager spawns = new SpawnManager();
        AuthManager auth = new AuthManager(settings, messages, db, spawns);
        MESSAGES = messages;
        DB = db;
        AUTH = auth;

        AuthCommands userCommands = new AuthCommands(auth, messages);
        AdminCommands adminCommands = new AdminCommands(settings, messages, db, auth, spawns);
        CommandRegistrationCallback.EVENT.register((d, access, env) -> {
            userCommands.register(d);
            adminCommands.register(d);
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> auth.onJoin(handler.getPlayer(), server));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> auth.onQuit(handler.getPlayer(), server));
        ServerTickEvents.END_SERVER_TICK.register(auth::tick);
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            if (settings.bool("Purge.useAutoPurge", false)) {
                long cutoff = System.currentTimeMillis() - settings.integer("Purge.daysBeforeRemovePlayer", 60) * 86_400_000L;
                LOGGER.info("Auto purge removed {} account(s)", db.purgeOlderThan(cutoff));
            }
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> db.close());

        UseBlockCallback.EVENT.register((p, w, h, hit) -> auth.isUnauthenticated(p) ? InteractionResult.FAIL : InteractionResult.PASS);
        UseItemCallback.EVENT.register((p, w, h) -> auth.isUnauthenticated(p) ? InteractionResult.FAIL : InteractionResult.PASS);
        UseEntityCallback.EVENT.register((p, w, h, e, hit) -> auth.isUnauthenticated(p) ? InteractionResult.FAIL : InteractionResult.PASS);
        AttackBlockCallback.EVENT.register((p, w, h, pos, dir) -> auth.isUnauthenticated(p) ? InteractionResult.FAIL : InteractionResult.PASS);
        AttackEntityCallback.EVENT.register((p, w, h, e, hit) -> auth.isUnauthenticated(p) ? InteractionResult.FAIL : InteractionResult.PASS);

        ServerMessageEvents.ALLOW_CHAT_MESSAGE.register((msg, sender, params) -> {
            if (auth.allowChat() || !auth.isUnauthenticated(sender)) return true;
            auth.denyChat(sender);
            return false;
        });
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, src, amt) ->
                !(entity instanceof ServerPlayer sp && auth.isUnauthenticated(sp)));

        LOGGER.info("AuthMe (Fabric port) loaded");
    }
}
