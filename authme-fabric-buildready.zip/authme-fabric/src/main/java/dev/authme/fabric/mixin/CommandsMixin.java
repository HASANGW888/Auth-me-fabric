package dev.authme.fabric.mixin;

import com.mojang.brigadier.ParseResults;
import dev.authme.fabric.AuthMeMod;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.server.level.ServerPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Blocks commands (except the allowed list) for unauthenticated players. */
@Mixin(Commands.class)
public class CommandsMixin {
    @Inject(method = "performCommand", at = @At("HEAD"), cancellable = true)
    private void authme$blockCommands(ParseResults<CommandSourceStack> parse, String command, CallbackInfo ci) {
        if (AuthMeMod.AUTH == null) return;
        CommandSourceStack src = parse.getContext().getSource();
        if (src.getEntity() instanceof ServerPlayer p
                && AuthMeMod.AUTH.isUnauthenticated(p)
                && !AuthMeMod.AUTH.isCommandAllowed(command)) {
            src.sendFailure(AuthMeMod.MESSAGES.comp("error.denied_command"));
            ci.cancel();
        }
    }
}
