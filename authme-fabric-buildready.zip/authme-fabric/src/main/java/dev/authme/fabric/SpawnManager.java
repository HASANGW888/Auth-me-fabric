package dev.authme.fabric;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.portal.TeleportTransition;
import net.minecraft.world.phys.Vec3;

import java.nio.file.Files;
import java.nio.file.Path;

public class SpawnManager {
    public static class Loc {
        public String dim;
        public double x, y, z;
        public float yaw, pitch;
    }

    private static class Data { Loc spawn; Loc first; }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private Data data = new Data();

    public SpawnManager() { load(); }

    private Path file() { return Config.dir().resolve("spawn.json"); }

    private void load() {
        try {
            if (Files.exists(file())) {
                Data d = GSON.fromJson(Files.readString(file()), Data.class);
                if (d != null) data = d;
            }
        } catch (Exception e) { AuthMeMod.LOGGER.error("Could not read spawn.json", e); }
    }

    private void save() {
        try { Files.writeString(file(), GSON.toJson(data)); }
        catch (Exception e) { AuthMeMod.LOGGER.error("Could not write spawn.json", e); }
    }

    public static Loc of(ServerPlayer p) {
        Loc l = new Loc();
        l.dim = p.level().dimension().toString();
        l.x = p.getX(); l.y = p.getY(); l.z = p.getZ();
        l.yaw = p.getYRot(); l.pitch = p.getXRot();
        return l;
    }

    public Loc spawn() { return data.spawn; }
    public Loc firstSpawn() { return data.first; }
    public void setSpawn(Loc l) { data.spawn = l; save(); }
    public void setFirstSpawn(Loc l) { data.first = l; save(); }

    public boolean teleport(ServerPlayer p, Loc l, MinecraftServer server) {
        if (l == null || l.dim == null) return false;
        ServerLevel target = null;
        for (ServerLevel lv : server.getAllLevels()) {
            if (lv.dimension().toString().equals(l.dim)) { target = lv; break; }
        }
        if (target == null) return false;
        p.teleport(new TeleportTransition(target, new Vec3(l.x, l.y, l.z), Vec3.ZERO, l.yaw, l.pitch,
                TeleportTransition.DO_NOTHING));
        return true;
    }
}
