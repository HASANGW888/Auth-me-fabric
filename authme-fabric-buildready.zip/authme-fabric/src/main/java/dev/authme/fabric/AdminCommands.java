package dev.authme.fabric;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.Date;
import java.util.List;

public class AdminCommands {
    private final Settings settings;
    private final Messages messages;
    private final Database db;
    private final AuthManager auth;
    private final SpawnManager spawns;

    public AdminCommands(Settings settings, Messages messages, Database db, AuthManager auth, SpawnManager spawns) {
        this.settings = settings; this.messages = messages; this.db = db; this.auth = auth; this.spawns = spawns;
    }

    private static RequiredArgumentBuilder<CommandSourceStack, String> arg(String n) {
        return Commands.argument(n, StringArgumentType.word());
    }

    private static LiteralArgumentBuilder<CommandSourceStack> sub(String name, String perm) {
        return Commands.literal(name).requires(Permissions.require("authme.admin." + perm, 3));
    }

    private static String s(CommandContext<CommandSourceStack> c, String n) { return StringArgumentType.getString(c, n); }

    private static int ok(CommandContext<CommandSourceStack> c, String text) {
        c.getSource().sendSuccess(() -> Component.literal(text), false);
        return 1;
    }

    private static int err(CommandContext<CommandSourceStack> c, String text) {
        c.getSource().sendFailure(Component.literal(text));
        return 0;
    }

    private ServerPlayer online(CommandContext<CommandSourceStack> c, String name) {
        return c.getSource().getServer().getPlayerList().getPlayerByName(name);
    }

    public void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("authme")
            .executes(c -> ok(c, "AuthMe: register, unregister, changepassword, forcelogin, getip, lastlogin, accounts, "
                    + "reload, version, purge, setspawn, spawn, setfirstspawn, firstspawn, totpdisable, recent"))

            .then(sub("register", "register").then(arg("player").then(arg("password").executes(c -> {
                String n = s(c, "player");
                if (db.get(n) != null) return err(c, "Player already registered.");
                String e = auth.validatePassword(n, s(c, "password"));
                if (e != null) return err(c, messages.get(e, "%valid_chars", settings.str("settings.restrictions.allowedPasswordCharacters", "[!-~]*")));
                db.insert(n, PasswordHasher.hash(s(c, "password")), "");
                return ok(c, "Registered " + n);
            }))))

            .then(sub("unregister", "unregister").then(arg("player").executes(c -> {
                String n = s(c, "player");
                if (db.get(n) == null) return err(c, "Player not registered.");
                db.delete(n);
                ServerPlayer p = online(c, n);
                if (p != null) auth.deauthenticate(p, c.getSource().getServer());
                return ok(c, "Unregistered " + n);
            })))

            .then(sub("changepassword", "changepassword").then(arg("player").then(arg("password").executes(c -> {
                String n = s(c, "player");
                if (db.get(n) == null) return err(c, "Player not registered.");
                String e = auth.validatePassword(n, s(c, "password"));
                if (e != null) return err(c, messages.get(e, "%valid_chars", settings.str("settings.restrictions.allowedPasswordCharacters", "[!-~]*")));
                db.updatePassword(n, PasswordHasher.hash(s(c, "password")));
                return ok(c, "Password changed for " + n);
            }))))

            .then(sub("forcelogin", "forcelogin").then(arg("player").executes(c -> {
                ServerPlayer p = online(c, s(c, "player"));
                if (p == null) return err(c, "Player is not online.");
                auth.forceLogin(p, c.getSource().getServer());
                return ok(c, "Forced login for " + AuthManager.name(p));
            })))

            .then(sub("getip", "getip").then(arg("player").executes(c -> {
                String n = s(c, "player");
                ServerPlayer p = online(c, n);
                if (p != null) return ok(c, n + "'s IP: " + AuthManager.ip(p));
                Database.Account a = db.get(n);
                return a == null ? err(c, "Unknown player.") : ok(c, n + "'s last IP: " + a.ip());
            })))

            .then(sub("lastlogin", "lastlogin").then(arg("player").executes(c -> {
                Database.Account a = db.get(s(c, "player"));
                if (a == null) return err(c, "Player not registered.");
                return ok(c, a.realName() + " last login: " + new Date(a.lastLogin()) + " from " + a.ip());
            })))

            .then(sub("accounts", "accounts").then(arg("player").executes(c -> {
                Database.Account a = db.get(s(c, "player"));
                if (a == null) return err(c, "Player not registered.");
                List<String> names = db.namesByIp(a.ip());
                return ok(c, names.size() + " account(s) on " + a.ip() + ": " + String.join(", ", names));
            })))

            .then(sub("reload", "reload").executes(c -> {
                settings.reload(); messages.reload();
                return ok(c, "AuthMe config and messages reloaded (database backend changes need a restart).");
            }))

            .then(Commands.literal("version").executes(c -> ok(c, "AuthMe Fabric port 0.2.0 (based on AuthMeReloaded 5.7.0)")))

            .then(sub("purge", "purge").then(Commands.argument("days", IntegerArgumentType.integer(1)).executes(c -> {
                long cutoff = System.currentTimeMillis() - IntegerArgumentType.getInteger(c, "days") * 86_400_000L;
                return ok(c, "Purged " + db.purgeOlderThan(cutoff) + " account(s).");
            })))

            .then(sub("recent", "seerecent").executes(c -> {
                StringBuilder sb = new StringBuilder("Recent logins:");
                for (Database.Account a : db.recent(5)) sb.append("\n ").append(a.realName()).append(" - ").append(new Date(a.lastLogin()));
                return ok(c, sb.toString());
            }))

            .then(sub("totpdisable", "totpdisable").then(arg("player").executes(c -> {
                if (db.get(s(c, "player")) == null) return err(c, "Player not registered.");
                db.setTotp(s(c, "player"), null);
                return ok(c, "Two-factor disabled for " + s(c, "player"));
            })))

            .then(sub("setspawn", "setspawn").executes(c -> {
                spawns.setSpawn(SpawnManager.of(c.getSource().getPlayerOrException()));
                return ok(c, "Spawn set.");
            }))
            .then(sub("setfirstspawn", "setfirstspawn").executes(c -> {
                spawns.setFirstSpawn(SpawnManager.of(c.getSource().getPlayerOrException()));
                return ok(c, "First spawn set.");
            }))
            .then(sub("spawn", "spawn").executes(c ->
                spawns.teleport(c.getSource().getPlayerOrException(), spawns.spawn(), c.getSource().getServer())
                        ? 1 : err(c, "No spawn set.")))
            .then(sub("firstspawn", "firstspawn").executes(c ->
                spawns.teleport(c.getSource().getPlayerOrException(), spawns.firstSpawn(), c.getSource().getServer())
                        ? 1 : err(c, "No first spawn set.")))
        );
    }
}
