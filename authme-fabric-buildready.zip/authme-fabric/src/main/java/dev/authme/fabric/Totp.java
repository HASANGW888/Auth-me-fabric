package dev.authme.fabric;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.security.SecureRandom;

/** RFC 6238 TOTP (HMAC-SHA1, 6 digits, 30s step). */
public final class Totp {
    private static final String B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

    private Totp() {}

    public static String newSecret() {
        byte[] b = new byte[20];
        new SecureRandom().nextBytes(b);
        return encode(b);
    }

    public static String url(String issuer, String user, String secret) {
        return "otpauth://totp/" + issuer + ":" + user + "?secret=" + secret + "&issuer=" + issuer;
    }

    public static boolean verify(String secret, String code) {
        try {
            int c = Integer.parseInt(code.trim());
            long t = System.currentTimeMillis() / 30000L;
            byte[] key = decode(secret);
            for (int i = -1; i <= 1; i++) if (gen(key, t + i) == c) return true;
        } catch (Exception ignored) {}
        return false;
    }

    private static int gen(byte[] key, long counter) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA1");
        mac.init(new SecretKeySpec(key, "HmacSHA1"));
        byte[] h = mac.doFinal(ByteBuffer.allocate(8).putLong(counter).array());
        int off = h[h.length - 1] & 0xf;
        int bin = ((h[off] & 0x7f) << 24) | ((h[off + 1] & 0xff) << 16) | ((h[off + 2] & 0xff) << 8) | (h[off + 3] & 0xff);
        return bin % 1_000_000;
    }

    static String encode(byte[] data) {
        StringBuilder sb = new StringBuilder();
        int buffer = 0, bits = 0;
        for (byte x : data) {
            buffer = (buffer << 8) | (x & 0xff);
            bits += 8;
            while (bits >= 5) {
                sb.append(B32.charAt((buffer >> (bits - 5)) & 31));
                bits -= 5;
            }
            buffer &= (1 << bits) - 1;
        }
        if (bits > 0) sb.append(B32.charAt((buffer << (5 - bits)) & 31));
        return sb.toString();
    }

    static byte[] decode(String s) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        int buffer = 0, bits = 0;
        for (char c : s.toUpperCase().toCharArray()) {
            int v = B32.indexOf(c);
            if (v < 0) continue;
            buffer = (buffer << 5) | v;
            bits += 5;
            if (bits >= 8) {
                o.write((buffer >> (bits - 8)) & 0xff);
                bits -= 8;
                buffer &= (1 << bits) - 1;
            }
        }
        return o.toByteArray();
    }
}
