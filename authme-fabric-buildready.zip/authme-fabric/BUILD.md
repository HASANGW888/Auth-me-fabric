# Building authme-fabric (Minecraft 1.21.11, Fabric)

Requires **JDK 21** (any vendor) and internet access (Loom downloads Minecraft, Mojang mappings and Fabric API).

    ./gradlew build          # Windows: gradlew.bat build

Result: `build/libs/authme-fabric-0.2.0.jar`  (the `-sources` jar, if present, is NOT the mod).
Drop it into the server's `mods/` folder together with Fabric API 0.141.x for 1.21.11.

No local toolchain? Push this folder to a GitHub repo: the included workflow
(`.github/workflows/build.yml`) builds it and attaches the jar as a downloadable artifact on the Actions run.
