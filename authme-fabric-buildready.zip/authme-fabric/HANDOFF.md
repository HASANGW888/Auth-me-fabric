# AuthMe -> Fabric 1.21.11 (all stages in one drop, UNTESTED, never compiled)

## Implemented
- Datasource: SQLite / MySQL / MariaDB / PostgreSQL (DataSource.* keys, table `authme`, AuthMe column names), auto purge
- Commands: /login /register /logout /unregister /changepassword (+l, reg, cp), /captcha, /2fa & /totp (add|confirm|remove|code)
- /authme: register, unregister, changepassword, forcelogin, getip, lastlogin, accounts, reload, version, purge, recent,
  totpdisable, setspawn, spawn, setfirstspawn, firstspawn
- Permissions via fabric-permissions-api: authme.admin.<sub> (default OP lvl 3), authme.allowmultipleaccounts
- Restrictions: freeze, interact/attack, chat, damage, command allow-list (mixin), inventory click/drop (mixin)
- Limbo: spawn/firstspawn teleport and restore after login, session by IP, login timeout, reminders
- Join checks: name regex, name case, maxJoinPerIp, kickNonRegistered; maxRegPerIp, maxLoginPerIp, captcha, kickOnWrongPassword
- config.yml (AuthMe key names for implemented options) + messages/messages_en.yml (AuthMe key layout)

## Changes in this pass (still never compiled)
- Security fix: only players that actually authenticated refresh their session on quit (kicked/unauthenticated players could previously create a session and bypass login by IP)
- IP now read from connection.getRemoteAddress() (IPv6-safe, no dependency on ServerPlayer#getIpAddress)
- Added min/max nickname length checks (settings.restrictions.minNicknameLength / maxNicknameLength)
- Added AuthMeApi (isAuthenticated, isRegistered, forceLogin, forceLogout)

## Intentionally skipped (per user)
- Email features; password algorithms other than PBKDF2-SHA256 (so existing AuthMe DB hashes will NOT verify)

## Not implemented
- Other languages of messages, BungeeCord/Velocity plugin messaging, ProtocolLib-equivalent inventory hiding,
  SaveQuitLocation, converters from other plugins, debug commands, public API, Vault/Essentials hooks, async DB.

## Most likely compile/runtime problems (check first)
1. Versions in gradle.properties / build.gradle (loom, loader, fabric-api, fabric-permissions-api).
2. fabric-permissions-api 0.5.0 may predate MC 1.21.11's permission rework: if the build or /authme permission checks fail, try 0.6.x
2b. TeleportTransition constructor + DO_NOTHING, ServerPlayer.teleport(TeleportTransition) (SpawnManager).
3. Mixin targets: Commands#performCommand, ServerGamePacketListenerImpl#handleContainerClick / #handlePlayerAction.
4. ServerGamePacketListenerImpl#getPlayer(), Fabric callback return types (InteractionResult).
5. Permissions.require / Permissions.check generics with CommandSourceStack.
Build: `gradle wrapper` once (no wrapper is included), then `./gradlew build`. Output: build/libs/authme-fabric-0.2.0.jar
License: AuthMeReloaded is GPLv3, so this port must stay GPLv3.

## Build-readiness pass (this session)
Still NOT compiled by Loom: the sandbox could not reach maven.fabricmc.net / Maven Central / Mojang. What WAS done:
- Versions pinned to the official 1.21.11 example mod: Loom 1.18-SNAPSHOT (`net.fabricmc.fabric-loom-remap`), Loader 0.19.5, Fabric API 0.141.6+1.21.11, Gradle 9.7.1 wrapper (included).
- fabric-permissions-api 0.5.0 -> 0.6.1 (0.5.0 targets 1.21.9; 0.6.x is the 1.21.11 line).
- Mixin: `player` is `private @Final` in 1.21.11 (as in Fabric API's own mixin); now `@Shadow @Final private`.
- authme.mixins.json: `injectors.defaultRequire = 1` so a mis-targeted injection crashes at startup instead of silently dropping protection.
- Cross-checked against Fabric API 0.139.4 source: TeleportTransition ctor + DO_NOTHING, all event/callback signatures (InteractionResult, ALLOW_CHAT_MESSAGE, ALLOW_DAMAGE, JOIN/DISCONNECT, CommandRegistrationCallback), sendSuccess(Supplier,boolean), handler.getPlayer().
- Cross-checked against fabric-permissions-api v0.6.1 source: require(String,int), check(Entity,String,boolean).
- javac over all sources: the only errors are missing external classes (Minecraft/Fabric/Brigadier/Mixin/JDBC drivers); no project-internal errors.
- Totp verified against RFC 6238 vectors; PasswordHasher round-trip verified.
Still unverified by a compiler: mixin target names (Commands#performCommand, ServerGamePacketListenerImpl#handleContainerClick/#handlePlayerAction) and ServerCommonPacketListenerImpl#getRemoteAddress. defaultRequire=1 will surface a wrong mixin target immediately on first server start.
